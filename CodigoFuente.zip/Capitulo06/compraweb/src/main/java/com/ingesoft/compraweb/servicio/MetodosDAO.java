package com.ingesoft.compraweb.servicio;

import java.util.List;

import com.ingesoft.compraweb.modelo.Usuario;

public interface MetodosDAO {
	
	public void nuevo(Usuario usuario);
	public void actualizar(Usuario usuario);
    public void eliminar(Usuario usuario);
    public List <Usuario> listarTodos();
    public Usuario buscarPorId(String id);
    public List<Usuario> buscarPorCampo(String campo1,String campo2, String valor);
    public Usuario buscarPorCuenta(String cuenta);
    
    public long contarCuentaClave(String cuenta,String clave);
    public Usuario buscarCuentaClave(String cuenta,String clave);
    
   

}
