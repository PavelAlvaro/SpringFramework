package com.ingesoft.compraweb.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.ingesoft.compraweb.modelo.Usuario;

public class ImplementDAO implements MetodosDAO {
	
	
	private MongoOperations em;
    
    public ImplementDAO(MongoOperations em){
	    this.em=em;
	}
	
    public static final String COLLECTION_NAME = "usuarios";
    
	@Override
    public void nuevo(Usuario usuario) {
		if (!em.collectionExists(Usuario.class)) {
        	em.createCollection(Usuario.class);
        }  
		em.insert(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void actualizar(Usuario usuario) {
    	em.save(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void eliminar(Usuario usuario) {
    	em.remove(usuario, COLLECTION_NAME);
        
    }
 
    @Override
    public List <Usuario> listarTodos() {
    	return em.findAll(Usuario.class, COLLECTION_NAME);
    }
    
    @Override
    public Usuario buscarPorId(String id) {
    	
    	Usuario usuario=em.findById(id, Usuario.class, COLLECTION_NAME);  
   	 	return usuario; 
    	
    }
    
    @Override
    public long contarCuentaClave(String cuenta,String clave){  
    	long conta= em.count(new Query(Criteria.where("cuenta").is(cuenta).and("clave").is(clave)),
    			Usuario.class, COLLECTION_NAME);
    	 return conta;  
	} 
    
    @Override
    public Usuario buscarCuentaClave(String cuenta,String clave){  
    
    	 Usuario user=em.findOne(new Query(Criteria.where("cuenta").is(cuenta).and("clave").is(clave)),
	    			Usuario.class, COLLECTION_NAME);
    	  return user;
	}
    
    @Override
    public List<Usuario> buscarPorCampo(String campo1,String campo2, String valor){  
    	Criteria criteria = new Criteria();
        criteria.orOperator(Criteria.where(campo1).regex(valor),Criteria.where(campo2).regex(valor));
        Query query = new Query(criteria);
        List<Usuario> user=em.find( query,Usuario.class, COLLECTION_NAME);  
        return user;  
	} 
    
    public Usuario buscarPorCuenta(String cuenta){ 
    	Usuario user=em.findOne( new Query(Criteria.where("cuenta").is(cuenta)),
        Usuario.class, COLLECTION_NAME);  
	    return user; 
	} 
}
