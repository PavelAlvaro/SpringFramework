package com.ingesoft.compraweb.servicio;

import java.util.List;

import org.springframework.data.mongodb.core.MongoOperations;

import com.ingesoft.compraweb.modelo.Usuario;

public class ImplementDAO implements MetodosDAO {
	
	private MongoOperations em;
    
    public ImplementDAO(MongoOperations em){
	    this.em=em;
	}
	
    public static final String COLLECTION_NAME = "usuarios";
    
	@Override
    public void nuevo(Usuario usuario) {
		if (!em.collectionExists(Usuario.class)) {
        	em.createCollection(Usuario.class);
        }  
		em.insert(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void actualizar(Usuario usuario) {
    	em.save(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void eliminar(Usuario usuario) {
    	em.remove(usuario, COLLECTION_NAME);
        
    }
 
    @Override
    public List <Usuario> listarTodos() {
    	return em.findAll(Usuario.class, COLLECTION_NAME);
    }
    
    @Override
    public Usuario buscarPorId(String id) {
    	
    	Usuario usuario=em.findById(id, Usuario.class, COLLECTION_NAME);  
   	 	return usuario; 
    	
    }

}
