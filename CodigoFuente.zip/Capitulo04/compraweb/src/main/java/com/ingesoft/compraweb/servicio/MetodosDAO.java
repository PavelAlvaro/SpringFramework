package com.ingesoft.compraweb.servicio;

import java.util.List;

import com.ingesoft.compraweb.modelo.Usuario;

public interface MetodosDAO {
	
	public void nuevo(Usuario usuario);
	public void actualizar(Usuario usuario);
    public void eliminar(Usuario usuario);
    public List <Usuario> listarTodos();
    public Usuario buscarPorId(String id);

}
