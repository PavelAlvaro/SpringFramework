package com.ingesoft.compraweb;

import static org.testng.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.MetodosDAO;


@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"
		,"file:src/main/webapp/WEB-INF/spring/security-context.xml"
		,"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@WebAppConfiguration
public class SistemaTest extends AbstractTestNGSpringContextTests{

	private static final String cuenta = "cuenta5";
	private static final String clave = "clave5";
	
	@Autowired
	private MetodosDAO metodosDAO;
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@BeforeMethod
	public void setup() {
		//System.setProperty("webdriver.firefox.bin","C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
		System.setProperty("webdriver.gecko.driver", "C:\\java\\webdriver\\geckodriver.exe");
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).
		build();
	}
	
	@Test
	public void ingreso_sistema() {
		WebDriver driver = new FirefoxDriver();
		driver.get("http://localhost:8080/compraweb/seguridad/ingreso");
		System.out.println("Page Title is " + driver.getTitle());
		assertEquals(".:LOGIN:.", driver.getTitle());
		driver.findElement(By.id("j_username")).sendKeys(cuenta);
		driver.findElement(By.id("j_password")).sendKeys(clave);
		driver.findElement(By.id("baceptar")).click();
		System.out.println("cuenta es " + driver.findElement(By.id("lcuenta")).getAttribute("title"));
		assertEquals("cuenta5", driver.findElement(By.id("lcuenta")).getAttribute("title"));
		//driver.quit();
	}
}
