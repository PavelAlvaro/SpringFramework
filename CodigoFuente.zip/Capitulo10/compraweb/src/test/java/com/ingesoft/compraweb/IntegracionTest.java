package com.ingesoft.compraweb;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.MetodosDAO;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"
		,"file:src/main/webapp/WEB-INF/spring/security-context.xml"
		,"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@WebAppConfiguration
public class IntegracionTest extends AbstractTestNGSpringContextTests{
	
	@Autowired
	private MetodosDAO metodosDAO;
	
	@Autowired
	private WebApplicationContext wac;
	
	private MockMvc mockMvc;
	
	@BeforeMethod
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).
		build();
	}
	
	@Test
	public void modificar_usuario() throws Exception {
		
		Usuario u=new Usuario();
		u.setNombre("test_integracion");
		u.setCuenta("test_integracion");
		u.setClave("test_integracion");
		u.setEstado("A");
		u.setRol("test_ope");
		metodosDAO.nuevo(u);
		String id=u.getId();
		System.out.println("Usuario id "+id);
		System.out.println("Usuario nombre "+u.getNombre());
		this.mockMvc.perform(post("/usuario/modificar").param("idusuario",
				id).param("tbnombre","test_modificado"))
				.andExpect(view().name("redirect:/usuario/listar"));
		u=metodosDAO.buscarPorId(id);
		System.out.println("Usuario id "+u.getId());
		System.out.println("Usuario nombre "+u.getNombre());
				
	}
}
