package com.ingesoft.compraweb;
import static org.testng.Assert.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.testng.annotations.Test;
import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.MetodosDAO;


@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
@WebAppConfiguration
public class UnitariasTest extends AbstractTestNGSpringContextTests{
	
	@Autowired
	private MetodosDAO metodosDAO;
	
	@Test
	public void testUsuario() {
	   Usuario u=new Usuario();
	   u.setNombre("test_nombre");
	   u.setCuenta("test_cuenta");
	   u.setClave("test_clave");
	   u.setEstado("A");
	   u.setRol("test_ope");
	   metodosDAO.nuevo(u);
	
	   String id=u.getId();
	   System.out.println("Usuario id "+id);
	   assertTrue(id!=null);
	  
	   u=metodosDAO.buscarPorId(id);
	   System.out.println("buscar por id "+u);
	   assertNotNull(u);
	   assertEquals(id,u.getId());
	   assertEquals("test_cuenta",u.getCuenta());
	}
}
