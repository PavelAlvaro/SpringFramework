package com.ingesoft.compraweb.controlador;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.ImplementDAO;


@Controller
public class UsuarioController {

	private static final Logger logger = LoggerFactory.getLogger(UsuarioController.class);
	
	@Autowired
	private ImplementDAO servicio;
	
	@RequestMapping(value = "usuario/listar")
	public String listar(Model model) {
		logger.info("listar...");
		List<Usuario> usuarios;
		usuarios=(List<Usuario>) servicio.listarTodos();
		model.addAttribute("lista",usuarios);
		
		return "usuario/listar";
	}
	
	@RequestMapping(value = "usuario/nuevo")
	public String nuevo(Model model,HttpServletRequest hsr) {
		
		return "usuario/nuevo";
	}
	
	@RequestMapping(value = "usuario/nuevo",method = RequestMethod.POST)
	public String aceptar(Model model,HttpServletRequest hsr) {
		logger.info("nuevo...");
		String nombre = hsr.getParameter("tbnombre");
		String cuenta = hsr.getParameter("tbcuenta");
		String clave = hsr.getParameter("tbclave");
		String rol = hsr.getParameter("tbrol");
		Usuario usuario=new Usuario();
		usuario.setNombre(nombre);
		usuario.setCuenta(cuenta);
		usuario.setClave(clave);
		usuario.setRol(rol);
		usuario.setEstado("A");
		servicio.nuevo(usuario);
		return "redirect:/";
	}
	
	@RequestMapping(value = "usuario/eliminar")
	public String eliminar(Model model,HttpServletRequest hsr) {
		logger.info("eliminar...");
		String id = hsr.getParameter("idusuario");
		Usuario usuario=new Usuario();
		usuario=servicio.buscarPorId(id);
		servicio.eliminar(usuario);
		return "redirect:/usuario/listar";
	}
	
	@RequestMapping(value = "usuario/modificar")
	public String modificar(Model model,HttpServletRequest hsr) {
		logger.info("modificar...");
		String id = hsr.getParameter("idusuario");
		Usuario usuario=new Usuario();
		usuario=servicio.buscarPorId(id);
		model.addAttribute("usuario",usuario);
		return "usuario/modificar";
	}
	
	@RequestMapping(value = "usuario/modificar",method = RequestMethod.POST)
	public String aceptarModificar(Model model,HttpServletRequest hsr) {
		logger.info("nuevo...");
		String id = hsr.getParameter("idusuario");
		String nombre = hsr.getParameter("tbnombre");
		String cuenta = hsr.getParameter("tbcuenta");
		String clave = hsr.getParameter("tbclave");
		String rol = hsr.getParameter("tbrol");
		Usuario usuario=new Usuario();
		usuario=servicio.buscarPorId(id);
		usuario.setNombre(nombre);
		usuario.setCuenta(cuenta);
		usuario.setClave(clave);
		usuario.setRol(rol);
		servicio.actualizar(usuario);
		return "redirect:/usuario/listar";
	}
	
	@RequestMapping(value = "usuario/buscar")
	public String buscar(Model model,HttpServletRequest hsr) {
		logger.info("buscar...");
		
		
		
		return "usuario/buscar";
	}
	
	@RequestMapping(value="usuario/listanombres", method=RequestMethod.GET )
    public @ResponseBody List<Usuario> listanombres(String term) {
        List<Usuario> usuarios;
        usuarios=servicio.buscarPorCampo("cuenta","nombre", term);
        return usuarios;
    }
	
}
