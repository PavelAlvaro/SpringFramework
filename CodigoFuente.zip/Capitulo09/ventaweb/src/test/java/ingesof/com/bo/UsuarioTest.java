package ingesof.com.bo;

import java.util.List;

import ingesof.com.bo.modelos.Usuario;
import ingesof.com.bo.servicios.MetodosDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

@Transactional
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml"})
@WebAppConfiguration
public class UsuarioTest extends AbstractTestNGSpringContextTests{

	@Autowired
	private MetodosDao metodosDAO;
	
	@Test
	public void testListUsers() {
	  List<Usuario> listUsu=metodosDAO.listarUsuarios();
	  System.out.println("verificarUsuarios: Lista no es vacia? " + (listUsu.size() >= 0));
	  System.out.println("lista de usuarios son? " + (listUsu.size()));
	  assertEquals(listUsu.size(), 5); 
		
	}
	
	
}
