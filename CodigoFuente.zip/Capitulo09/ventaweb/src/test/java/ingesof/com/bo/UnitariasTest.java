package ingesof.com.bo;

import static org.testng.Assert.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.testng.annotations.Test;

import ingesof.com.bo.modelos.Usuario;
import ingesof.com.bo.servicios.MetodosDao;

@Transactional
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/spring/root-context.xml"})
@WebAppConfiguration
public class UnitariasTest extends AbstractTestNGSpringContextTests{

	
	@Autowired
	private MetodosDao metodosDAO;
	
	@Test
	public void testUsuario() {
		Usuario u=new Usuario();
		   u.setNombre("test_nombre");
		   u.setCuenta("test_cuenta");
		   u.setClave("test_clave");
		   u.setEstado("A");
		   u.setRol("test_ope");
		   metodosDAO.nuevoUsuario(u);
		   System.out.println("Prueba Usuario");
		   int codigo=u.getId();
		   assertTrue(u!=null);
		
	}
	

}
