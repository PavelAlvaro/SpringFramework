package ingesof.com.bo.servicios;

import java.util.List;

import ingesof.com.bo.modelos.Usuario;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class MetodosImp implements MetodosDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	
	@Override
    @Transactional
    public void nuevoUsuario(Usuario u) {
        Session session = this.sessionFactory.getCurrentSession();
        session.persist(u);
        
    }
    
    @Override
    @Transactional
    public List<Usuario> listarUsuarios(){
        Session session = this.sessionFactory.getCurrentSession();
        @SuppressWarnings("unchecked")
		List<Usuario> listaUsuarios = session.createQuery("from Usuario").list();
        return listaUsuarios;
    }
    
    @Override
    @Transactional
    public void actualizarUsuario(Usuario u) {
        Session session = this.sessionFactory.getCurrentSession();
        session.update(u);
        
    }
    
    @Override
    @Transactional
    public void eliminarUsuario(Usuario u)
    {
        Session session = this.sessionFactory.getCurrentSession();
        session.delete(u);
        
    }
    
    @Override
    @Transactional
    public Usuario buscarUsuarioPorId(int id) {
        Session session = this.sessionFactory.getCurrentSession();
        Usuario usuario=(Usuario) session.get(Usuario.class, id);
        return usuario;
    }

}
