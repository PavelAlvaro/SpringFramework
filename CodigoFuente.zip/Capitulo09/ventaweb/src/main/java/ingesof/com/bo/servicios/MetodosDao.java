package ingesof.com.bo.servicios;

import ingesof.com.bo.modelos.Usuario;

import java.util.List;

public interface MetodosDao {

	public void nuevoUsuario(Usuario u);
	public List<Usuario> listarUsuarios();
	public void actualizarUsuario(Usuario u);
	public Usuario buscarUsuarioPorId(int id);
	public void eliminarUsuario(Usuario p);
	
}
