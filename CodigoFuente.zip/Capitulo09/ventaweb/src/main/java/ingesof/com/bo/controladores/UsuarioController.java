package ingesof.com.bo.controladores;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import ingesof.com.bo.modelos.Usuario;
import ingesof.com.bo.servicios.MetodosDao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UsuarioController {
	
	private static final Logger logger = LoggerFactory.getLogger(UsuarioController.class);
	
	@Autowired
	private MetodosDao metodosDAO;
	
	@RequestMapping(value = "usuario/listar")
	public String listar(Model model) {
		logger.info("listar...");
		List<Usuario> usuarios;
		usuarios=metodosDAO.listarUsuarios();
		model.addAttribute("lista",usuarios);
		return "usuario/listar";
	}
	// el resto del codigo
	@RequestMapping(value = "usuario/nuevo")
	public String nuevo(Model model,HttpServletRequest hsr) {

		return "usuario/nuevo";
	}

	@RequestMapping(value = "usuario/nuevo",method = RequestMethod.POST)
	public String aceptar (Model model,HttpServletRequest hsr) {
		logger.info("nuevo...");
		String nombre = hsr.getParameter("tbnombre");
		String cuenta = hsr.getParameter("tbcuenta");
		String clave = hsr.getParameter("tbclave");
		String rol = hsr.getParameter("tbrol");
		Usuario usuario=new Usuario();
		usuario.setNombre(nombre);
		usuario.setCuenta(cuenta);
		usuario.setClave(clave);
		usuario.setRol(rol);
		usuario.setEstado("A");
		metodosDAO.nuevoUsuario(usuario);
		return "home";
	}
	//el resto del codigo
	@RequestMapping(value = "usuario/eliminar/{id}",method = RequestMethod.GET)
	public String eliminar(@PathVariable("id") int id,Model model) {
		Usuario usuario=new Usuario();
		usuario=metodosDAO.buscarUsuarioPorId(id);
		metodosDAO.eliminarUsuario(usuario);
		return "redirect:/usuario/listar";
	}
	
	@RequestMapping(value = "usuario/editar/{id}",method = RequestMethod.GET)
	public String modificar(@PathVariable("id") int id,Model model) {
			logger.info("editar...");
			Usuario usuario=new Usuario();
			usuario=metodosDAO.buscarUsuarioPorId(id);
			model.addAttribute("usuario",usuario);
			return "usuario/editar";
	}
	
	@RequestMapping(value = "usuario/editar",method = RequestMethod.POST)
	public String aceptarModificar(Model model,HttpServletRequest hsr) {
			logger.info("guardar editar...");
			String id = hsr.getParameter("tbid");
			String nombre = hsr.getParameter("tbnombre");
			String cuenta = hsr.getParameter("tbcuenta");
			String clave = hsr.getParameter("tbclave");
			String rol = hsr.getParameter("tbrol");
			Usuario usuario=new Usuario();
			usuario=metodosDAO.buscarUsuarioPorId(Integer.parseInt(id));
			usuario.setNombre(nombre);
			usuario.setCuenta(cuenta);
			usuario.setClave(clave);
			usuario.setRol(rol);
			metodosDAO.actualizarUsuario(usuario);
			return "redirect:/usuario/listar";
	}
}
