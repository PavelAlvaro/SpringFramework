package com.ingesoft.compraweb.controlador;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;






import com.ingesoft.compraweb.modelo.Producto;
import com.ingesoft.compraweb.servicio.MetodosDAO;
import com.mongodb.gridfs.GridFSDBFile;

@Controller
public class ProductoController {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductoController.class);
	
	@Autowired
	private MetodosDAO metodosDAO;
	
	@RequestMapping(value = "producto/nuevo")
	public String nuevo(Model model,HttpServletRequest hsr) {
		logger.info("producto...");
		return "producto/nuevo";
	}
	
	@RequestMapping(value = "producto/nuevo",method = RequestMethod.POST)
	public String aceptarNuevo(Model model,@RequestParam("file") MultipartFile file,HttpServletRequest hsr) throws IOException{
		logger.info("producto aceptar...");
		String nombre = hsr.getParameter("tbnombre");
		String tipo = hsr.getParameter("cbtipo");
		String precio = hsr.getParameter("tbprecio");
		Producto producto=new Producto();
		producto.setNombre(nombre);
		producto.setTipo(tipo);
		producto.setPrecio(Integer.parseInt(precio));
		metodosDAO.nuevoProducto(producto);
		String id_archivo=metodosDAO.save(file,producto.getId());
		producto.setId_archivo(id_archivo);
		metodosDAO.actualizarProducto(producto);
		return "producto/nuevo";
	}
	
	@RequestMapping(value = "producto/listar")
	public String listar(Model model,HttpServletRequest hsr) {
		logger.info("producto listar...");
		List<Producto> lista=metodosDAO.listarProductos();
		model.addAttribute("lista",lista);
		return "producto/listar";
	}
	
	@RequestMapping(value = "producto/imagenMostrar", method = RequestMethod.GET)
	public void showImage(@RequestParam("id") String itemId, HttpServletResponse response, HttpServletRequest request)
			throws ServletException, IOException {
		GridFSDBFile imagen = metodosDAO.getByIdArchivo(itemId);
		response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
		response.getOutputStream().write(IOUtils.toByteArray(imagen.getInputStream()));
		response.getOutputStream().close();

	}

}
