package com.ingesoft.compraweb.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="productos")
public class Producto {
	
	@Id
	private String id;
	private String nombre;
	private String tipo;
	private Integer precio;
	private String id_archivo;
	/* metodos getters y setters */
	
	
	public String getId_archivo() {
		return id_archivo;
	}
	public void setId_archivo(String id_archivo) {
		this.id_archivo = id_archivo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public Integer getPrecio() {
		return precio;
	}
	public void setPrecio(Integer precio) {
		this.precio = precio;
	}
	
	

}
