package com.ingesoft.compraweb.servicio;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ingesoft.compraweb.modelo.Usuario;

public class AccesoMongoDB implements UserDetailsService{

	private MongoOperations mongoOps;
	
	public AccesoMongoDB(MongoOperations mongoOps){
	        this.mongoOps=mongoOps;
	    }
	
	public static final String COLLECTION_NAME = "usuarios";
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
		
		List<GrantedAuthority> roles =new ArrayList<GrantedAuthority>();
		Usuario usuario=mongoOps.findOne( new Query(Criteria.where("cuenta").is(username)),
                Usuario.class, COLLECTION_NAME);
        
        
        System.out.println("cuenta: "+username);
        if (usuario==null)
        {
            System.out.println("usuario no registrado: ");
            throw new UsernameNotFoundException("usuario no registrado");
            
        }
        else
        {
            System.out.println("rol: "+usuario.getRol());
            
           	roles.add(new SimpleGrantedAuthority(usuario.getRol()));
        }
        
        UserDetails  user = new User(usuario.getCuenta(), usuario.getClave(), true, true, true, true, roles);
        return user;
	}
	
}
