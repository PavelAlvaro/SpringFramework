package com.ingesoft.compraweb.modelo;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class ReporteUsuariosPDF extends AbstractITextPdfView{
	
	private static final Font DATO_FONT = new Font(Font.getFamily("TIMES_ROMAN"), 12,Font.BOLD);
		
	@Override
    protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
      
        document.setPageSize(PageSize.LETTER);
        document.setMargins(40f, 50f, 30f, 26f);
      
    }

    @Override
    protected void prepareWriter(Map<String, Object> model, PdfWriter writer, HttpServletRequest request) throws DocumentException {
        writer.setViewerPreferences(getViewerPreferences());
    }
    
    

    @Override
    protected int getViewerPreferences() {
        return 0;
    }
	
	@Override
    protected void buildPdfDocument(Map<String, Object> model, Document doc,
            PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
		Font timeroman18 = new Font(Font.getFamily("TIMES_ROMAN"), 12, Font.NORMAL);
		Font cambria14 = new Font(Font.getFamily("TIMES_ROMAN"), 14, Font.BOLD);
		Font cambria10 = new Font(Font.getFamily("TIMES_ROMAN"), 10, Font.BOLD);
		
		ServletContext servletContext = request.getSession().getServletContext();
		String imgPath = "/resources/images/oglobalshop.png";
	    String absoluteImgPath = servletContext.getRealPath(imgPath);
		Image logo = Image.getInstance(absoluteImgPath); 
		logo.setAbsolutePosition(40f, 680f);
		logo.scaleAbsoluteWidth(70f);
		logo.scaleAbsoluteHeight(70f);
		doc.add(logo);
		
		
		
		List<Usuario> listUsuario = (List<Usuario>) model.get("listUsuario");
		
		Paragraph p1=new Paragraph(" ", cambria14);
        p1.setAlignment(Element.ALIGN_CENTER);
        doc.add(p1);               
               
        p1=new Paragraph("REPORTE DE USUARIOS", cambria14);
        //p1.setSpacingBefore(130);
        p1.setAlignment(Element.ALIGN_CENTER);
        doc.add(p1);
		
        p1=new Paragraph("COMPRAWEB - COMERCIO ONLINE", cambria10);
        //p1.setSpacingBefore(130);
        p1.setAlignment(Element.ALIGN_CENTER);
        doc.add(p1);
        
        Paragraph p2=new Paragraph(" ", cambria14);
        p2.setAlignment(Element.ALIGN_CENTER);
        doc.add(p2);
        
        Paragraph p3=new Paragraph(" ", cambria14);
        p3.setAlignment(Element.ALIGN_CENTER);
        doc.add(p3);
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100.0f);
        table.setWidths(new float[] {0.8f, 3.2f, 3.0f, 1.0f, 2.0f});
        table.setSpacingBefore(10);
         
        // define font for table header row
        Font font = new Font(Font.getFamily("HELVETICA"), 8, Font.BOLD);
        font.setColor(BaseColor.WHITE);
        
        Font font1 = new Font(Font.getFamily("HELVETICA"), 8, Font.NORMAL);
        font1.setColor(BaseColor.BLACK);
         
        // define table header cell
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(BaseColor.BLACK);
        cell.setPadding(5);
         
        // write table header
        cell.setPhrase(new Phrase("NRO.", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("NOMBRE", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("CUENTA", font));
        table.addCell(cell);
 
        cell.setPhrase(new Phrase("ROL", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("ESTADO", font));
        table.addCell(cell);
        
        
         
        // write table row data
        int numero=1;
        for (Usuario aEquipo : listUsuario) {
        	table.addCell(new Phrase(String.valueOf(numero), font1));
            table.addCell(new Phrase(aEquipo.getNombre(), font1));
            table.addCell(new Phrase(aEquipo.getCuenta(), font1));
            table.addCell(new Phrase(aEquipo.getRol(), font1));
            table.addCell(new Phrase(aEquipo.getEstado(), font1));
            
            numero++;
        }
         
        doc.add(table);
	 }

}
