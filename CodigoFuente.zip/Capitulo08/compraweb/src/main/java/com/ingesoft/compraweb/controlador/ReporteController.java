package com.ingesoft.compraweb.controlador;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ingesoft.compraweb.modelo.ReporteUsuariosPDF;
import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.MetodosDAO;

@Controller
public class ReporteController {
	
private static final Logger logger = LoggerFactory.getLogger(ReporteController.class);
	
	@Autowired
	private MetodosDAO metodosDAO;
	
	@RequestMapping(value="reporte/usuario")
	public ModelAndView nuevo(HttpServletRequest hsr) {
		Map modelo=new HashedMap();
		
		List<Usuario> listEquipo=metodosDAO.listarTodos();
		modelo.put("listUsuario", listEquipo);
				
		ReporteUsuariosPDF reporte= new ReporteUsuariosPDF();
        return new ModelAndView(reporte,modelo);
	}

}
