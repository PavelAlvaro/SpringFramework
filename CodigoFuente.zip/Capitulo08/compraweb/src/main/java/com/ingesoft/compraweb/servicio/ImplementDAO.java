package com.ingesoft.compraweb.servicio;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.ingesoft.compraweb.modelo.Producto;
import com.ingesoft.compraweb.modelo.Usuario;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSFile;

public class ImplementDAO implements MetodosDAO {
	
	
	private MongoOperations em;
	private GridFsOperations gridfsOps;
    
    public ImplementDAO(GridFsTemplate gridfsOps,MongoOperations em){
	    this.em=em;
	    this.gridfsOps=gridfsOps;
	}
    public static final String COLLECTION_NAME_PRODUCTO = "productos";
    public static final String COLLECTION_NAME = "usuarios";
    
    
	@Override
    public void nuevo(Usuario usuario) {
		if (!em.collectionExists(Usuario.class)) {
        	em.createCollection(Usuario.class);
        }  
		em.insert(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void actualizar(Usuario usuario) {
    	em.save(usuario, COLLECTION_NAME);
    }
 
    @Override
    public void eliminar(Usuario usuario) {
    	em.remove(usuario, COLLECTION_NAME);
        
    }
 
    @Override
    public List <Usuario> listarTodos() {
    	return em.findAll(Usuario.class, COLLECTION_NAME);
    }
    
    @Override
    public Usuario buscarPorId(String id) {
    	
    	Usuario usuario=em.findById(id, Usuario.class, COLLECTION_NAME);  
   	 	return usuario; 
    	
    }
    
    @Override
    public long contarCuentaClave(String cuenta,String clave){  
    	long conta= em.count(new Query(Criteria.where("cuenta").is(cuenta).and("clave").is(clave)),
    			Usuario.class, COLLECTION_NAME);
    	 return conta;  
	} 
    
    @Override
    public Usuario buscarCuentaClave(String cuenta,String clave){  
    
    	 Usuario user=em.findOne(new Query(Criteria.where("cuenta").is(cuenta).and("clave").is(clave)),
	    			Usuario.class, COLLECTION_NAME);
    	  return user;
	}
    
    @Override
    public List<Usuario> buscarPorCampo(String campo1,String campo2, String valor){  
    	Criteria criteria = new Criteria();
        criteria.orOperator(Criteria.where(campo1).regex(valor),Criteria.where(campo2).regex(valor));
        Query query = new Query(criteria);
        List<Usuario> user=em.find( query,Usuario.class, COLLECTION_NAME);  
        return user;  
	} 
    @Override
    public Usuario buscarPorCuenta(String cuenta){ 
    	Usuario user=em.findOne( new Query(Criteria.where("cuenta").is(cuenta)),
        Usuario.class, COLLECTION_NAME);  
	    return user; 
	} 
    /* el resto del codigo*/
    @Override
	public String save(MultipartFile file,String idproducto) throws IOException {
    	    	
    	BufferedImage imageni = ImageIO.read(file.getInputStream());
    	if(imageni!=null)
		{
    		
    		BufferedImage imagenfoto2=redimensionar(imageni, 1024, 768);
			ByteArrayOutputStream foto2 = new ByteArrayOutputStream();
		    ImageIO.write(imagenfoto2, "jpg", foto2);
		    InputStream fotodos = new ByteArrayInputStream(foto2.toByteArray());	
		    
		    DBObject otros = new BasicDBObject();
		    otros.put("id_producto", idproducto);
			
		    
    		GridFSFile archivo =gridfsOps.store(fotodos,file.getContentType(),file.getOriginalFilename(),otros);
		    archivo.save();
		    System.out.println("input "+archivo.getId().toString());
		    return archivo.getId().toString();//
		}
    	else return null;
    }
    
    @Override
	public GridFSDBFile getByIdArchivo(String id) {
    	
    	  return this.gridfsOps.findOne(new Query(Criteria.where("_id").is(id)));
    	  
    }
        
    @Override
    public void nuevoProducto(Producto producto) {
		if (!em.collectionExists(Producto.class)) {
        	em.createCollection(Producto.class);
        }  
		em.insert(producto, COLLECTION_NAME_PRODUCTO);
    }
    
    @Override
    public Producto buscarPorIdProducto(String id) {
    	
    	Producto usuario=em.findById(id, Producto.class, COLLECTION_NAME_PRODUCTO);  
   	 	return usuario; 
    	
    }
    
    @Override
    public void actualizarProducto(Producto producto) {
    	em.save(producto, COLLECTION_NAME_PRODUCTO);
    }
    
    @Override
    public List <Producto> listarProductos() {
    	return em.findAll(Producto.class, COLLECTION_NAME_PRODUCTO);
    }
    
    @Override
	public BufferedImage redimensionar(BufferedImage bufferedImage, int newW, int newH) {
        int w = bufferedImage.getWidth();
        int h = bufferedImage.getHeight();
        BufferedImage imagenRedimensionada = new BufferedImage(newW, newH, bufferedImage.getType());
        Graphics2D g = imagenRedimensionada.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(bufferedImage, 0, 0, newW, newH, 0, 0, w, h, null);
        g.dispose();
        return imagenRedimensionada;
    }
}
