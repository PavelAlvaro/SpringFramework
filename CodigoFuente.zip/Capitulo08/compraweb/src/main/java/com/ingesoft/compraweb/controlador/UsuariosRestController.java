package com.ingesoft.compraweb.controlador;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ingesoft.compraweb.modelo.RestException;
import com.ingesoft.compraweb.modelo.Usuario;
import com.ingesoft.compraweb.servicio.ImplementDAO;

@RestController
@RequestMapping("/rest")
public class UsuariosRestController {
	
	private static final Logger logger = LoggerFactory.getLogger(UsuariosRestController.class);
	
	@Autowired
	private ImplementDAO servicio;
	
	@RequestMapping(value = "/usuarios", method=RequestMethod.POST)
	public void save(@RequestBody Usuario user) {
		servicio.nuevo(user);
	}
	@RequestMapping(value = "/usuarios", method=RequestMethod.GET)
	public List<Usuario> list() {
	return servicio.listarTodos();
	}
	// el resto del codigo
	@RequestMapping(value="/usuarios/{id}", method=RequestMethod.GET)
	public Usuario get(@PathVariable("id") String id) {
		Usuario user = servicio.buscarPorId(id);
		if (user == null) {
			throw new RestException(1, "Usuario no encontrado!",
			"Usuario con id: " + id + " no fue encontrado en el sistema.");
		}
		
			return user;
	}
	// el resto del codigo
	@RequestMapping(value="/usuarios/{id}", method=RequestMethod.PUT)
	public void update(@PathVariable("id") String id, @RequestBody Usuario user) {
		Usuario usuario=new Usuario();
		usuario=servicio.buscarPorId(id);
		usuario.setClave(user.getClave());
		usuario.setCuenta(user.getCuenta());
		usuario.setEstado(user.getEstado());
		usuario.setNombre(user.getNombre());
		usuario.setRol(user.getRol());
		servicio.actualizar(usuario);
	}
	@RequestMapping(value="/usuarios/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Boolean> delete(@PathVariable("id") String id) {
		Usuario usuario=new Usuario();
		usuario=servicio.buscarPorId(id);
		servicio.eliminar(usuario);
		return new ResponseEntity<Boolean>(Boolean.TRUE, HttpStatus.OK);
	}

}
