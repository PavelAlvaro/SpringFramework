package com.ingesoft.compraweb.servicio;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;




import com.ingesoft.compraweb.modelo.Producto;
import com.ingesoft.compraweb.modelo.Usuario;
import com.mongodb.gridfs.GridFSDBFile;

public interface MetodosDAO {
	
	public void nuevo(Usuario usuario);
	public void actualizar(Usuario usuario);
    public void eliminar(Usuario usuario);
    public List <Usuario> listarTodos();
    public Usuario buscarPorId(String id);
    public List<Usuario> buscarPorCampo(String campo1,String campo2, String valor);
    public Usuario buscarPorCuenta(String cuenta);
    
    /* el resto del codigo */
    public void nuevoProducto(Producto producto);
    public List <Producto> listarProductos();
    public Producto buscarPorIdProducto(String id);
    public void actualizarProducto(Producto producto);
    public String save(MultipartFile file,String idproducto) throws IOException;
    public GridFSDBFile getByIdArchivo(String id);
    public BufferedImage redimensionar(BufferedImage bufferedImage, int newW, int newH);
    /* el resto del codigo */
    
    public long contarCuentaClave(String cuenta,String clave);
    public Usuario buscarCuentaClave(String cuenta,String clave);
    
    
    
   

}
