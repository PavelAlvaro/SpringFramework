package com.ingesoft.compraweb.modelo;


import java.util.HashMap;
import java.util.Map;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.velocity.VelocityEngineUtils;

public class MailMail {
	
	private JavaMailSender mailSender;
	private VelocityEngine velocityEngine;
	 
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}
	
	public void setVelocityEngine(VelocityEngine velocityEngine) {
		  this.velocityEngine = velocityEngine;
	}
		
 	public void enviarCorreo(String to, String titulo, String descripcion) {
 		SimpleMailMessage message = new SimpleMailMessage();
 		message.setFrom("pavel.alvaro@gmail.com");
		message.setTo(to);
		message.setSubject(titulo);
		message.setText(descripcion);
		mailSender.send(message);	
	}
	
	public void enviarCorreoAdjunto(final String to,final String titulo,final String descripcion,final String adjunto) throws MessagingException{
		
		MimeMessage message=mailSender.createMimeMessage();
		MimeMessageHelper helper= new MimeMessageHelper(message,true);
 		helper.setFrom("pavel.alvaro@gmail.com");
		helper.setTo(to);
		helper.setSubject(titulo);
		helper.setText(descripcion);
		FileSystemResource archivo=	new FileSystemResource(adjunto);
		helper.addAttachment("adjunto",archivo);
		mailSender.send(message);
	}
	
	public void enviarCorreoHtml(String to,String titulo,String descripcion,String plantilla) throws MessagingException{
		
		MimeMessage message=mailSender.createMimeMessage();
		MimeMessageHelper helper= new MimeMessageHelper(message,true);
 		helper.setFrom("pavel.alvaro@gmail.com");
		helper.setTo(to);
		helper.setSubject(titulo);
		Map<String, Object> model= new HashMap<String,Object>();
		model.put("contenido",descripcion);
		String texto=VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, plantilla,model);
		helper.setText(texto,true);
		mailSender.send(message);
	}
	
}
